<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Paredes" tilewidth="64" tileheight="64" tilecount="32" columns="8">
 <image source="Paredes.png" width="512" height="256"/>
</tileset>
